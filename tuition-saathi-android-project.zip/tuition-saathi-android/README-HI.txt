TUITION SAATHI - Android APK project

APK banane ka sabse aasan tareeqa (GitHub se):

1. Is ZIP ko extract karein.
2. GitHub par apne repository (tuition-saathi) ko kholein.
3. Add file > Upload files par jaakar ZIP extract karne ke baad project ke
   ANDAR ke sabhi folders/files upload karein. ZIP file ko seedha upload na karein.
4. Commit changes karein. Repository ka default branch 'main' hona chahiye.
5. GitHub repository me Actions tab kholein.
6. "Build Tuition Saathi APK" workflow select karke Run workflow dabayein
   (ya main branch par push karne ke baad automatic build chalega).
7. Build complete hone par workflow run kholein, neeche Artifacts me
   tuition-saathi-debug-apk download karein.
8. ZIP artifact ko extract karein. app-debug.apk milega. Android phone par
   APK install karte waqt permission maang sakta hai.

Android Studio se:
- Project folder open karein.
- JDK 17 aur Android SDK Platform 35 install hon.
- Build > Build Bundle(s) / APK(s) > Build APK(s).

Note:
- Aapka HTML app WebView ke andar local chalega.
- App ka data abhi isi phone ke local storage me rehta hai; cloud sync nahi hai.
- Ye debug APK hai, Play Store release ke liye signed release build alag se banana hoga.
- PIN app-lock ko strong account security na samjhein; data local device par hi hai.
